package com.example.booking.entity;

public enum Role {
    STUDENT, INSTRUCTOR,ADMIN;
}
